/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package balle_en_mouvement;

import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author USER
 */
public class ThreadClass extends Thread{
    private final Ball boule;
    public ThreadClass(Ball boule) {
        this.boule=boule;
    }
    public void paint(Graphics2D g) {
        g.fillOval(boule.x, boule.y, boule.rad, boule.rad);
    }
    @Override
    public void run() {
        while(true){
            try {
                boule.move();             
                Thread.sleep(5);
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadClass.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
