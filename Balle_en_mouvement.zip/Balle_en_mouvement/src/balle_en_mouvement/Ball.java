/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package balle_en_mouvement;

import java.awt.*;
import java.util.Random;
//import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

/**
 *
 * @author USER
 */
public class Ball extends JPanel{
    int x = (int)(Math.random()*400)+0;
    int y = (int)(Math.random()*400)+0;
    int xa = 1;
    int ya = 1;
    JPanel game;
    int rad=40;        
    //Gestion couleurs aléatoire
    static Color[] colors={Color.BLACK,Color.BLUE,Color.CYAN,Color.DARK_GRAY,Color.GRAY,Color.GREEN
        ,Color.LIGHT_GRAY,Color.MAGENTA,Color.ORANGE,Color.PINK,Color.RED,Color.WHITE,Color.YELLOW};
    Random rand=new Random();

    Color newColor(){
        return colors[rand.nextInt(colors.length)];
    }
    Color cColor=newColor();

    public Ball(JPanel J) {
        super();
        this.game=J;
        System.out.println(x+" "+y);    
    }
    //Movement de la balle avec gestion collision des bords
    void move() throws InterruptedException {
        if (x + xa < 0)xa = 1;
        if (x + xa > game.getWidth()- rad)xa = -1;
        if (y + ya < 0)ya = 1;
        if (y + ya > game.getHeight() - rad)ya = -1;
        x = x + xa;
        y = y + ya;
        this.repaint();
    }
    //Fonction permettant l'arrête (Stop) ou la reprise du movement de la balle (Set)
    void StopXa(){
        xa=0;
    }
    void StopYa(){
        ya=0;
    }
    void setXa(){
        xa=1;
    }
    void setYa(){
        ya=1;
    }
    //Dimmenssion
    int GetRad(){
        return rad;
    }
    //Dessiner l'ojet
    public void paint(Graphics2D g) {
        g.fillOval(x, y,rad,rad);
        g.setColor(cColor);
    }
}   

