/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
*/
package balle_en_mouvement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Math.sqrt;
import java.time.chrono.ThaiBuddhistChronology;
import java.util.Vector;

/**
 *
 * @author USER
*/
public class Animation extends JPanel implements ActionListener{
    //Initialisation
    static Timer t; 
    static JPanel container = new JPanel(),SouthPanel=new JPanel(),NorthPanel=new JPanel();
    static JLabel LabelSc,IncrementationSc,LabelTimer,m,s,ms;
    static JButton Start,plus,moin; //,Stop,
    static JFrame frame;
    static Animation game;static Vector<Ball> Dessins;   
    static int x=0,Score=0;
    static Thread thread;
    
    public Animation(){
        Dessins = new Vector<Ball>();        
        LabelSc=new JLabel("Score : ");IncrementationSc=new JLabel("0");
        LabelTimer=new JLabel("Timer : ");m=new JLabel("0");s=new JLabel("0");ms=new JLabel("0");
        Start=new JButton("Start");plus=new JButton("+");moin=new JButton("-");//Stop=new JButton("Stop");
        t = new Timer(0,new Chronomettre(m,s,ms));       
        Start.addActionListener(this);plus.addActionListener(this);moin.addActionListener(this);//Stop.addActionListener(this);     
        plus.setVisible(false);
        moin.setVisible(false);   
    }
    //Raffraichissement de la balle
    @Override
    public void paint(Graphics g) {	
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        Dessins.stream().forEach((Dessin) -> {
            Dessin.paint(g2d);
        });
    }
    //Application de la fonction de détection de collision
    static void CollisionEffectue(){
        for(int i=0;i<Dessins.size();i++){
            if(x>=2 && i>=0 && i<Dessins.size()-1){
                if(Collision(Dessins.get(i),Dessins.get(i+1))==true){
                    Dessins.removeElementAt(i);Dessins.removeElementAt(i);
                    x-=2;
                    if(t.isRunning()==true){
                    Score+=10;  
                    IncrementationSc.setText(""+Score);}   
                }
                else {}
            }
        }
    }
    //Fonction de détection de collisions
    static boolean Collision(Ball C1,Ball C2){
        int d2 = ((C1.x-C2.x)*(C1.x-C2.x)) + ((C1.y-C2.y)*(C1.y-C2.y));
        if (d2 > (C1.rad + C2.rad)*(C1.rad + C2.rad))return false;
        else return true;    
    }
    public static void main(String[] args) throws InterruptedException {
	//Initialisation des panneaux
        frame = new JFrame("Animation");
        game = new Animation();
        frame.add(container);
        container.setLayout(new BorderLayout());
        container.add(game, BorderLayout.CENTER);
        container.add(NorthPanel,BorderLayout.NORTH);
        container.add(SouthPanel, BorderLayout.SOUTH);
        NorthPanel.setLayout(new FlowLayout());
        NorthPanel.add(LabelSc);NorthPanel.add(IncrementationSc);NorthPanel.add(LabelTimer);NorthPanel.add(m);NorthPanel.add(s);NorthPanel.add(ms);
        SouthPanel.setLayout(new FlowLayout());
        SouthPanel.add(Start);SouthPanel.add(plus);SouthPanel.add(moin);//SouthPanel.add(Stop);
        container.setVisible(true);
	frame.setSize(500,500);
	frame.setVisible(true);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Raffraichissement et test de collisions dans la frame
        while (true){
            if(Start.getText().equals("Stop"))CollisionEffectue(); 
            game.repaint();
            Thread.sleep(10);
        }
    }
    @Override
    public synchronized void actionPerformed(ActionEvent e) {    
        // Start timer,affichage des boutons, changement text du bouton
        if(e.getSource() == Start){ 
            if(Start.getText().equals("Start")){
                t.start();
                plus.setVisible(true);
                moin.setVisible(true);
                for (Ball Dessin : Dessins) {
                    Dessin.setXa();
                    Dessin.setYa();
                }  
                Start.setText("Stop");
            }
            else{
                if(Start.getText().equals("Stop")){
                    t.stop();
                    for (Ball Dessin : Dessins) {
                        Dessin.StopXa();
                        Dessin.StopYa();
                    } 
                    Start.setText("Start");
                }       
            }
        }
        /*
        Dans le cas ou Start transformé pose problème
        if(e.getSource()==Stop){  
            if(Stop.getText().equals("Stop")){
                t.stop();
                for (Ball Dessin : Dessins) {
                    Dessin.StopXa();
                    Dessin.StopYa();
                }  
            }
        }*/
        // Ajout d'une balle
        if(e.getSource() == plus && Start.getText().equals("Stop")){
            if(x>=10)x=x;
            else{
                x++;
                Dessins.add(new Ball(game));
                for (Ball Dessin : Dessins) {
                    thread = new Thread(new ThreadClass(Dessin));
                    thread.start();
                }  
            }
        }
        // Retrait d'une balle
        if(e.getSource() == moin){
            if(x<=0)x=x;
            else x--;
            if(x>=0)Dessins.removeElementAt(x);
        }
    }
}