/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package balle_en_mouvement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;

/**
 *
 * @author USER
 */
public class Chronomettre implements ActionListener{
    //Déclaration et Initialisation des variables    
    public int min=00;
    public int sec=00;
    public int ms=00;
    
    private JLabel M=new JLabel();
    private JLabel S=new JLabel();
    private JLabel MS=new JLabel();
    public Chronomettre(JLabel m,JLabel s,JLabel ms){
        this.M=m;
        this.S=s;
        this.MS=ms;
    }
    //Affichage du timer selon l'event
    @Override
    public void actionPerformed(ActionEvent e) {
        ms+=1;
        if (ms==100) {
            sec+=1;
            ms=0;
        }
        if (sec==60) {
            min+=1;
            sec=0;
        }
        if(min<10)M.setText("0"+min);else M.setText(""+min);
        if(sec<10)S.setText("0"+sec);else S.setText(""+sec);
        if(ms<10)MS.setText("+"+ms);else MS.setText(""+ms);
    }
}
